-- EJECUTAR EN xirectinternal.database.xirect.com
SELECT * FROM ModBallsNLogs_Dev order by logid desc