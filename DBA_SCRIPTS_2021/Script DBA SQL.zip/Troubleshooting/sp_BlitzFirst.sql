[dba].[sp_BlitzFirst] @help=1

[dba].[sp_BlitzFirst] @expertmode=1

