sp_BlitzCache

sp_BlitzCache @sortorder='reads'
--reads, cpu, duration, executions, xpm, memory grant, recent compilations.