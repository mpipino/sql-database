exec dba.sp_BlitzIndex

EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo'
, @TableName='Tbl_Distributor_Commissions_Temp_V2';

EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_DISTRIBUTOR';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header'; --BLOQUEA.
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_AUTOSHIPORDERS_HEADER';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='Distributor_Commissions_Bonus';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_adjustments';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_adjustments';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_adjustments';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_adjustments';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_adjustments';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_AUTOSHIPORDERS_HEADER';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_AUTOSHIPORDERS_HEADER';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_AUTOSHIPORDERS_HEADER';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='TBL_LOG_AUTOSHIP';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Detail';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Detail';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header';
EXEC dbo.sp_BlitzIndex @DatabaseName='Asea_Prod', @SchemaName='dbo', @TableName='tbl_Orders_Header_Snapshot';