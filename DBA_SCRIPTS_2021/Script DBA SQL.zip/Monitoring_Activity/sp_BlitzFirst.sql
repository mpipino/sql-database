dba.sp_BlitzFirst

[dba].[sp_BlitzFirst] @help=1

[dba].[sp_BlitzFirst] @expertmode=1

[dba].[sp_BlitzFirst] @CheckProcedureCache=1



--Use @CheckProcedureCache = 1 or run sp_BlitzCache for more analysis



