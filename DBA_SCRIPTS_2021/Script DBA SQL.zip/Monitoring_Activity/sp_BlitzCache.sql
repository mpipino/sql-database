[dba].sp_BlitzCache @sortorder='Reads'
[dba].sp_BlitzCache @StoredProcName = 'sp_CalculateVolume', @sortorder='Reads'
[dba].sp_BlitzCache @StoredProcName = 'sp_XC_Calculate_Commissions_v2'
[dba].sp_BlitzCache @StoredProcName = 'Commissions_Engine_CalculateGroupVolumes'
[dba].sp_BlitzCache @StoredProcName = 'Sp_Search_Criteria_Results_Pagination'


